---
description: "Steps to Prepare Favorite leek &amp;amp; baked potato soup"
title: "Steps to Prepare Favorite leek &amp;amp; baked potato soup"
slug: 2533-steps-to-prepare-favorite-leek-and-amp-baked-potato-soup
date: 2020-10-23T20:01:33.298Z
image: https://img-global.cpcdn.com/recipes/4566138243514368/751x532cq70/leek-baked-potato-soup-recipe-main-photo.jpg
thumbnail: https://img-global.cpcdn.com/recipes/4566138243514368/751x532cq70/leek-baked-potato-soup-recipe-main-photo.jpg
cover: https://img-global.cpcdn.com/recipes/4566138243514368/751x532cq70/leek-baked-potato-soup-recipe-main-photo.jpg
author: Randall Ford
ratingvalue: 4.8
reviewcount: 10
recipeingredient:
- " leek 68 in long"
- " leftover baked potatoes cold"
- " onion minced"
- " stock chicken or beef or veg"
- " butter"
- " olive oil"
- " salt split"
- " cracked black pepper split"
- " flour"
- " garlic powder"
- " ground coriander"
- " smoked paprika"
- " splash of Worcestershire sauce"
- " lemon juice"
- " or 3 DROPS liquid smoke"
recipeinstructions:
- "over medium heat"
- "Heat 1 tbsp. butter and olive oil in 3-4 quart pot."
- "cut leeks into 2-3 mm thick slices, put into bowl and separate into slivers"
- "add to hot oils"
- "add minced onion."
- "stir often with wooden spoon. Do not let leeks brown. They will become bitter."
- "add 1/2 of the salt and pepper"
- "after about 2-3 minutes, add garlic powder."
- "add remaining 2 tbsp. butter, melt."
- "add flour to create rue."
- "stirr often."
- "incorporate 2 cups of stock. Stir until smooth and silky."
- "add paprika, coriander, Worcestershire, lemon juice."
- "stir until well blended."
- "add a little more stock and reduce heat to a good simmer."
- "dice cold potatoes (I use yukon golds) any will work"
- "add to soup. stir."
- "after potatoes are added, the starch from them will continue to thicken it. add stock as needed from here out."
- "add 2-3 DROPS of liquid smoke. ONLY A COUPLE OF DROPS. This is strong flavor."
- "if you don&#39;t have liq. smoke, double smoked paprika. Or use a pinch of cumin."
- "let simmer 15-20 minutes. eat."
categories:
- Recipe
tags:
- leek
- 
- baked

katakunci: leek  baked 
nutrition: 254 calories
recipecuisine: American
preptime: "PT26M"
cooktime: "PT33M"
recipeyield: "3"
recipecategory: Dinner

type: post
---


![leek &amp; baked potato soup](https://img-global.cpcdn.com/recipes/4566138243514368/751x532cq70/leek-baked-potato-soup-recipe-main-photo.jpg)
<br>
Hey everyone, welcome to our recipe page, looking for the perfect leek &amp; baked potato soup recipe? look no further! We provide you only the perfect leek &amp; baked potato soup recipe here. We also have wide variety of recipes to try.
<br>

<i>Before you jump to leek &amp; baked potato soup recipe, you may want to read this short interesting healthy tips about <strong>Energy Raising Snacks</strong>.</i>
</br>

We all know that having healthy meals can help us feel better inside our bodies. Increasing our consumption of sensible foods while lowering the intake of unhealthy types plays a role in a more healthy feeling. A salad helps us feel better than a piece of pizza (physically in any case). This is usually a problem, nonetheless, in terms of eating between meals. Shopping for snack foods can be a struggle because you have a great number of options. There's nothing like one of these healthy foods when you really need an energy-boosting treat.

Healthy foods made from whole grains are fantastic for a quick snack. Starting your day with a piece of whole grain toasted bread can give you that added boost you need to get going. When you need a fast treat on your way out the door, do not forget to look for whole grain chips, pretzels, and crackers. Whole grains are usually better than refined grains included in white bread.

You do not have to look far to find a wide variety of healthy snacks that can be easily prepared. When you make the determination to be healthy, it's uncomplicated to find what you need to be successful at it.

<i>We hope you got insight from reading it, now let's go back to leek &amp; baked potato soup recipe. To cook leek &amp; baked potato soup you need <strong>15</strong> ingredients and <strong>21</strong> steps. Here is how you achieve it.
</i>
<!--inarticleads1-->
##### The ingredients needed to cook leek &amp; baked potato soup:

1. Get  leek 6-8 in. long
1. Provide  leftover baked potatoes (cold)
1. Get  onion (minced)
1. Get  stock (chicken or beef or veg.)
1. Use  butter
1. Prepare  olive oil
1. Use  salt (split)
1. Take  cracked black pepper (split)
1. Prepare  flour
1. Use  garlic powder
1. Prepare  ground coriander
1. Get  smoked paprika
1. Use  splash of Worcestershire sauce
1. Provide  lemon juice
1. Provide  or 3 DROPS liquid smoke

<!--inarticleads1-->
##### Instructions to make leek &amp; baked potato soup:

1. over medium heat
1. Heat 1 tbsp. butter and olive oil in 3-4 quart pot.
1. cut leeks into 2-3 mm thick slices, put into bowl and separate into slivers
1. add to hot oils
1. add minced onion.
1. stir often with wooden spoon. Do not let leeks brown. They will become bitter.
1. add 1/2 of the salt and pepper
1. after about 2-3 minutes, add garlic powder.
1. add remaining 2 tbsp. butter, melt.
1. add flour to create rue.
1. stirr often.
1. incorporate 2 cups of stock. Stir until smooth and silky.
1. add paprika, coriander, Worcestershire, lemon juice.
1. stir until well blended.
1. add a little more stock and reduce heat to a good simmer.
1. dice cold potatoes (I use yukon golds) any will work
1. add to soup. stir.
1. after potatoes are added, the starch from them will continue to thicken it. add stock as needed from here out.
1. add 2-3 DROPS of liquid smoke. ONLY A COUPLE OF DROPS. This is strong flavor.
1. if you don&#39;t have liq. smoke, double smoked paprika. Or use a pinch of cumin.
1. let simmer 15-20 minutes. eat.


<i>If you find this leek &amp; baked potato soup recipe useful please share it to your close friends or family, thank you and good luck.</i>
