---
title: "About"
date: 2019-10-29T13:49:23+06:00
draft: false

# image
image: "images/author.jpg"

# meta description
description: "this is meta description"

# type
type : "about"
---

Hi! We're Team Foodika. Kick back, stay a while, won't you? When you visit our corner of the internet, we want you to feel comfortable. Like did we just become best friends?! kind of comfortable. We're not here to shame you into making beef bourguignon when all you really want is Fireball meatballs. And if you do attempt that fancy-shmancy dish and fail spectacularly, we're not going to tsk-tsk you—because we've had plenty of OH, S#!T moments, too. (Wanna see 'em?)

That's not to say we're not serious about food. If you've come here to finally tackle an exasperatingly intense sourdough recipe, we can help explain the technique, step by step. We celebrate anyone who really loves to eat as much as those who actually get in the kitchen to cook. So wherever you fall on that spectrum, you'll find your people here.

That's why we want you to get to know us, too—the team behind Foodika. Scroll through to meet the people who work hard to bring you the stories and videos you see every month. We want you to love reading on and cooking from College Food as much as we love creating this space for you, so holler if you've got something you want us to know. We're all ears. (Did you know you can rate and comment on all our recipes, too?)