---
description: "Recipe of Quick Chicken Stir Fry with Sweet Soy Sauce (Ayam Kecap)"
title: "Recipe of Quick Chicken Stir Fry with Sweet Soy Sauce (Ayam Kecap)"
slug: 2533-recipe-of-quick-chicken-stir-fry-with-sweet-soy-sauce-ayam-kecap
date: 2020-10-03T19:13:41.064Z
image: https://img-global.cpcdn.com/recipes/5c3547488a5e8ebd/751x532cq70/chicken-stir-fry-with-sweet-soy-sauce-ayam-kecap-recipe-main-photo.jpg
thumbnail: https://img-global.cpcdn.com/recipes/5c3547488a5e8ebd/751x532cq70/chicken-stir-fry-with-sweet-soy-sauce-ayam-kecap-recipe-main-photo.jpg
cover: https://img-global.cpcdn.com/recipes/5c3547488a5e8ebd/751x532cq70/chicken-stir-fry-with-sweet-soy-sauce-ayam-kecap-recipe-main-photo.jpg
author: Clayton Lloyd
ratingvalue: 3
reviewcount: 7
recipeingredient:
- "250 gr chicken breast"
- "1 tbsp lemon juice"
- "1 tsp salt to marinate the chicken"
- "3 long red chilies"
- "4 tbsp sweet soy sauce"
- "2 spring onions"
- "1/2 red onion"
- "1 brown onion"
- "4 garlic cloves"
- "1 tsp salt"
- "1/2 tsp pepper"
- "1/2 tsp sugar"
- "2 cm ginger"
- "200 ml water"
- "3 tbsp cooking oil"
- " Cooking oil to deep fry"
recipeinstructions:
- "Marinate the chicken with lemon juice and salt, let stand for 5 mins."
- "Deep fry the chicken half cooked, cut the chicken into smaller pieces, put aside."
- "Chop red onion, garlics, chilies, spring onions. Slice brown onion and ginger."
- "Pre-heat cooking oil in a pan, cook onion and garlic until the aroma comes out, add brown onion, red chilies, and ginger, stir properly."
- "Add salt, sugar, pepper, and sweet soy sauce, mix well."
- "Add water and spring onion, stir until it boils, add chicken, stir well with medium heat u til caramelized."
- "Enjoy with rice or bread."
categories:
- Recipe
tags:
- chicken
- stir
- fry

katakunci: chicken stir fry 
nutrition: 165 calories
recipecuisine: American
preptime: "PT38M"
cooktime: "PT36M"
recipeyield: "1"
recipecategory: Dessert

type: post
---


![Chicken Stir Fry with Sweet Soy Sauce (Ayam Kecap)](https://img-global.cpcdn.com/recipes/5c3547488a5e8ebd/751x532cq70/chicken-stir-fry-with-sweet-soy-sauce-ayam-kecap-recipe-main-photo.jpg)
<br>
Hello everybody, welcome to our recipe page, If you're looking for recipes idea to cook today, look no further! We provide you only the perfect Chicken Stir Fry with Sweet Soy Sauce (Ayam Kecap) recipe here. We also have wide variety of recipes to try.
<br>

<i>Before you jump to Chicken Stir Fry with Sweet Soy Sauce (Ayam Kecap) recipe, you may want to read this short interesting healthy tips about <strong>Goodies that offer You Vitality</strong>.</i>
</br>

We are very mindful that eating healthy meals can help us really feel better within our bodies. If we eat more healthy snacks and less of the bad ones we usually feel much better. Eating more vegetables helps you feel better than eating a slice of pizza. Choosing healthier food choices can be difficult if it is snack time. Finding goodies that really help us feel better and increase our energy levels often involves lots of shopping and meticulous reading of labels. Here are some healthy snacks that can be used when you need a fast pick me up.

Foods made from whole grains are fantastic for a easy snack. A mid-morning snack of whole grain bread coupled with some protein will keep you until it's time for lunch break. Chips and crackers created from whole grains can be fantastic for quick snacks to eat on the go. Whole grains are generally better than highly processed grains included in white bread.

A large variety of instant health snacks is easily obtainable. Choosing to live a healthy lifestyle can be as uncomplicated as you want it to be.

<i>We hope you got insight from reading it, now let's go back to chicken stir fry with sweet soy sauce (ayam kecap) recipe. To cook chicken stir fry with sweet soy sauce (ayam kecap) you need <strong>16</strong> ingredients and <strong>7</strong> steps. Here is how you cook that.
</i>
<!--inarticleads1-->
##### The ingredients needed to cook Chicken Stir Fry with Sweet Soy Sauce (Ayam Kecap):

1. Get 250 gr chicken breast
1. Take 1 tbsp lemon juice
1. Take 1 tsp salt (to marinate the chicken)
1. Prepare 3 long red chilies
1. Get 4 tbsp sweet soy sauce
1. Prepare 2 spring onions
1. Take 1/2 red onion
1. You need 1 brown onion
1. Get 4 garlic cloves
1. You need 1 tsp salt
1. You need 1/2 tsp pepper
1. Take 1/2 tsp sugar
1. Use 2 cm ginger
1. Get 200 ml water
1. Take 3 tbsp cooking oil
1. Use  Cooking oil to deep fry

<!--inarticleads1-->
##### Instructions to make Chicken Stir Fry with Sweet Soy Sauce (Ayam Kecap):

1. Marinate the chicken with lemon juice and salt, let stand for 5 mins.
1. Deep fry the chicken half cooked, cut the chicken into smaller pieces, put aside.
1. Chop red onion, garlics, chilies, spring onions. Slice brown onion and ginger.
1. Pre-heat cooking oil in a pan, cook onion and garlic until the aroma comes out, add brown onion, red chilies, and ginger, stir properly.
1. Add salt, sugar, pepper, and sweet soy sauce, mix well.
1. Add water and spring onion, stir until it boils, add chicken, stir well with medium heat u til caramelized.
1. Enjoy with rice or bread.


<i>If you find this Chicken Stir Fry with Sweet Soy Sauce (Ayam Kecap) recipe valuable please share it to your close friends or family, thank you and good luck.</i>
