---
description: "Recipe of Quick Plantain fritters"
title: "Recipe of Quick Plantain fritters"
slug: 2533-recipe-of-quick-plantain-fritters
date: 2020-07-10T16:14:28.887Z
image: https://img-global.cpcdn.com/recipes/19498a78c7a84ae3/751x532cq70/plantain-fritters-recipe-main-photo.jpg
thumbnail: https://img-global.cpcdn.com/recipes/19498a78c7a84ae3/751x532cq70/plantain-fritters-recipe-main-photo.jpg
cover: https://img-global.cpcdn.com/recipes/19498a78c7a84ae3/751x532cq70/plantain-fritters-recipe-main-photo.jpg
author: Dale Davis
ratingvalue: 4.9
reviewcount: 6
recipeingredient:
- "3 plantains"
- "3 Potatoes"
- "1 onion"
- "To taste Salt"
- "To taste Jeera powder"
- "To taste Aamchur"
- "1 tsp Garam masala"
- "1 tsp Red chilli powder"
- "2 tsp Corn flour"
recipeinstructions:
- "Boil the plantains and potatoes for 3 whistles."
- "After they cool down,peel them and mask with a fork. Evenly."
- "Add the onions, and other masalas."
- "Mix properly. Add corn flour to it."
- "Make flat round tikkis and keep aside."
- "Heat very little oil in a on stick Pan and add the tikkis."
- "Turn both sides and cook properly."
categories:
- Recipe
tags:
- plantain
- fritters

katakunci: plantain fritters 
nutrition: 256 calories
recipecuisine: American
preptime: "PT26M"
cooktime: "PT34M"
recipeyield: "3"
recipecategory: Dessert

type: post
---


![Plantain fritters](https://img-global.cpcdn.com/recipes/19498a78c7a84ae3/751x532cq70/plantain-fritters-recipe-main-photo.jpg)
<br>
Hey everyone, welcome to our recipe site, If you're looking for new recipes to try this weekend, look no further! We provide you only the best Plantain fritters recipe here. We also have wide variety of recipes to try.
<br>

<i>Before you jump to Plantain fritters recipe, you may want to read this short interesting healthy tips about <strong>Treats that provide You Vitality</strong>.</i>
</br>

Wholesome eating encourages a feeling of wellness. When we eat more healthy foods and less of the unhealthy ones we usually feel much better. A salad helps us feel a lot better than a piece of pizza (physically in any case). Sometimes it's tough to find healthy foods for snacks between meals. Shopping for snacks can be a struggle because you have so many options. Here are a handful of healthy snacks which you can use when you need a quick pick me up.

One of the most popular treats is low fat yogurt. In fact, many people will substitute a container of yogurt for a healthy lunch-something we don't recommend. You can not beat yogurt when it comes to a wholesome snack though. It is a protein-rich resource of nutritious minerals and vitamins. Yogurt is often eaten to help manage the digestive system because it is so easily digestible by many people. Easy hint: pick unsweetened yogurt and include walnuts or flaxseeds. This reduces your sugar intake without lowering the taste of your snack.

You do not have to look far to locate a wide selection of healthy snacks that can be easily prepared. Being healthy and balanced doesnt need to be a battle-if you let it, it can be quite simple.

<i>We hope you got benefit from reading it, now let's go back to plantain fritters recipe. You can cook plantain fritters using <strong>9</strong> ingredients and <strong>7</strong> steps. Here is how you achieve that.
</i>
<!--inarticleads1-->
##### The ingredients needed to make Plantain fritters:

1. Take 3 plantains
1. Prepare 3 Potatoes
1. You need 1 onion
1. Prepare To taste Salt
1. Take To taste Jeera powder
1. Use To taste Aamchur
1. Take 1 tsp Garam masala
1. Provide 1 tsp Red chilli powder
1. Prepare 2 tsp Corn flour

<!--inarticleads1-->
##### Instructions to make Plantain fritters:

1. Boil the plantains and potatoes for 3 whistles.
1. After they cool down,peel them and mask with a fork. Evenly.
1. Add the onions, and other masalas.
1. Mix properly. Add corn flour to it.
1. Make flat round tikkis and keep aside.
1. Heat very little oil in a on stick Pan and add the tikkis.
1. Turn both sides and cook properly.


<i>If you find this Plantain fritters recipe valuable please share it to your friends or family, thank you and good luck.</i>
