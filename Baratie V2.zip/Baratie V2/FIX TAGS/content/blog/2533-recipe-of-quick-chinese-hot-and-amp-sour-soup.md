---
description: "Recipe of Quick Chinese Hot &amp;amp; Sour Soup"
title: "Recipe of Quick Chinese Hot &amp;amp; Sour Soup"
slug: 2533-recipe-of-quick-chinese-hot-and-amp-sour-soup
date: 2020-11-25T10:20:42.572Z
image: https://img-global.cpcdn.com/recipes/b0951eb9d5f1e374/751x532cq70/chinese-hot-sour-soup-recipe-main-photo.jpg
thumbnail: https://img-global.cpcdn.com/recipes/b0951eb9d5f1e374/751x532cq70/chinese-hot-sour-soup-recipe-main-photo.jpg
cover: https://img-global.cpcdn.com/recipes/b0951eb9d5f1e374/751x532cq70/chinese-hot-sour-soup-recipe-main-photo.jpg
author: Steven Morales
ratingvalue: 4.7
reviewcount: 12
recipeingredient:
- " Mushrooms"
- "100 g Shiitake Mushrooms Finely Diced"
- "1 TSP ShaoWing  Hua Tiao  Sherry Wine"
- "1 TSP Soy Sauce Preferably Kikkoman"
- "Pinch Granulated Sugar"
- "1/2 TSP Water"
- "1 TSP Cornstarch"
- "1 TSP Sesame Oil"
- " Base"
- "1 Handful Fresh Coriander Finely Chopped"
- "1 TSP Lao Gan Ma Spicy Chili Crisp"
- "2 TSP Black Vinegar"
- "1 TSP Sesame Oil"
- "1 TSP Apple Cider Vinegar"
- " Soup"
- "Pinch White Pepper"
- "2 TBSP Canola  Peanut  Vegetable Oil"
- "2 Chinese Dried Mushrooms Soaked Finely Sliced"
- "1 Handful Bamboo Shoots Fresh  Pickled"
- "1 Handful Chinese Black Fungus Soaked Finely Sliced"
- "600 ml Boiling Water"
- "1/2 Inch Ginger Finely Diced"
- "3/4 TSP Sea Salt"
- " Slurry 7 TSP Cornstarch  25ml Water"
- "1 Egg Lightly Beaten"
- "150 g Pressed Tofu Sliced Into Strips"
- "1/3 TSP Dark Soy Sauce"
- "1 TSP Light Soy Sauce"
- "3 TSP Chili Bean Sauce Preferably Lee Kum Kee"
- "1/2 TSP Granulated Sugar"
- " Fresh Coriander For Garnishing"
recipeinstructions:
- "Prepare the mushrooms.  In a bowl, add in mushrooms, shaoxing, soy, sugar, water, cornstarch and sesame oil.  Mix until well combined.  Cover with cling film and set aside in the fridge for at least 30 mins."
- "Prepare the base.  In a large serving bowl, add coriander, black vinegar, apple cider vinegar, pepper, chili crisp and sesame oil.  Mix until combine well.  Set aside."
- "Prepare the soup.  In a sauce pot over medium heat, add oil.  Once oil is heated up, add in ginger and the mushrooms mixture."
- "Saute until aromatic and until the mushrooms are slightly caramelized.  Add in Chinese mushrooms, bamboo and fungus.  Saute until well combine and aromatic."
- "Add in the boiling water.  *Adding boiling water will shorten the cooking time, hence containing the fragrance and flavors even more.*  Stir to combine well.  Add in dark, light soy, chili bean sauce, sugar and salt."
- "Stir to combine well.  Bring it up to a simmer.  Turn the heat down to low.  Add in slurry and stir to combine well."
- "Continue simmer for about 2 to 3 mins.  Add in beaten egg.  Stir for 20 secs.  Turn the heat up to medium."
- "Add in tofu.  Stir to combine well and simmer for another 1 to 2 mins.  The soup should thicken.  Taste and adjust for seasoning with salt."
- "Give it a final stir.  Remove from heat and transfer into the serving bowl with the coriander mixture.  Stir to combine well.  Taste and adjust for seasonings with vinegar or pepper.  Serve immediately with a garnish of coriander."
categories:
- Recipe
tags:
- chinese
- hot
- 

katakunci: chinese hot  
nutrition: 153 calories
recipecuisine: American
preptime: "PT32M"
cooktime: "PT59M"
recipeyield: "3"
recipecategory: Dinner

type: post
---


![Chinese Hot &amp; Sour Soup](https://img-global.cpcdn.com/recipes/b0951eb9d5f1e374/751x532cq70/chinese-hot-sour-soup-recipe-main-photo.jpg)
<br>
Hey everyone, welcome to our recipe page, If you're looking for recipes idea to cook today, look no further! We provide you only the perfect Chinese Hot &amp; Sour Soup recipe here. We also have wide variety of recipes to try.
<br>

<i>Before you jump to Chinese Hot &amp; Sour Soup recipe, you may want to read this short interesting healthy tips about <strong>Energy Boosting Treats</strong>.</i>
</br>

Wholesome eating encourages a feeling of well being. When we eat more healthy snacks and a lesser amount of of the bad ones we usually feel much better. Eating more fresh vegetables helps you feel a lot better than eating a slice of pizza. Sometimes it's difficult to find healthy foods for treats between meals. Finding snacks that will help us feel better and boost our levels of energy often involves lots of shopping and meticulous reading of labels. Why not try one of many following nutritious snacks the next time you need some extra energy?

Eating almonds is an excellent option as long as you don't possess a nut allergy. As an all-in-one energy booster, almonds offer you many health advantages. These nuts possess lots of vitamins E, B2, and manganese. Tryptophan, an enzyme also contained in turkey which induces drowsiness, is present in almonds. But once you eat almonds, you won't feel like you must sleep a while. Rather, these nuts help to reduce stress and provide a calming feeling throughout your body. Almonds frequently give a general increased a feeling of well-being.

A large variety of easy health snacks is easily obtainable. Choosing to live a healthy life style can be as simple as you want it to be.

<i>We hope you got benefit from reading it, now let's go back to chinese hot &amp; sour soup recipe. You can have chinese hot &amp; sour soup using <strong>31</strong> ingredients and <strong>9</strong> steps. Here is how you cook that.
</i>
<!--inarticleads1-->
##### The ingredients needed to cook Chinese Hot &amp; Sour Soup:

1. You need  Mushrooms:
1. Take 100 g Shiitake Mushrooms Finely Diced,
1. You need 1 TSP ShaoWing / Hua Tiao / Sherry Wine,
1. You need 1 TSP Soy Sauce Preferably Kikkoman,
1. Get Pinch Granulated Sugar,
1. Provide 1/2 TSP Water,
1. Take 1 TSP Cornstarch,
1. Take 1 TSP Sesame Oil,
1. Prepare  Base:
1. Use 1 Handful Fresh Coriander Finely Chopped,
1. Get 1 TSP Lao Gan Ma Spicy Chili Crisp,
1. Use 2 TSP Black Vinegar,
1. Get 1 TSP Sesame Oil,
1. Prepare 1 TSP Apple Cider Vinegar,
1. Provide  Soup:
1. Prepare Pinch White Pepper,
1. Provide 2 TBSP Canola / Peanut / Vegetable Oil,
1. Provide 2 Chinese Dried Mushrooms Soaked Finely Sliced,
1. Get 1 Handful Bamboo Shoots Fresh / Pickled,
1. You need 1 Handful Chinese Black Fungus Soaked Finely Sliced,
1. Take 600 ml Boiling Water,
1. Take 1/2 Inch Ginger Finely Diced,
1. Get 3/4 TSP Sea Salt,
1. Get  Slurry, 7 TSP Cornstarch + 25ml Water
1. Get 1 Egg Lightly Beaten,
1. You need 150 g Pressed Tofu Sliced Into Strips,
1. You need 1/3 TSP Dark Soy Sauce,
1. Use 1 TSP Light Soy Sauce,
1. Get 3 TSP Chili Bean Sauce Preferably Lee Kum Kee,
1. Prepare 1/2 TSP Granulated Sugar,
1. Provide  Fresh Coriander, For Garnishing

<!--inarticleads1-->
##### Instructions to make Chinese Hot &amp; Sour Soup:

1. Prepare the mushrooms. -  - In a bowl, add in mushrooms, shaoxing, soy, sugar, water, cornstarch and sesame oil. -  - Mix until well combined. -  - Cover with cling film and set aside in the fridge for at least 30 mins.
1. Prepare the base. -  - In a large serving bowl, add coriander, black vinegar, apple cider vinegar, pepper, chili crisp and sesame oil. -  - Mix until combine well. -  - Set aside.
1. Prepare the soup. -  - In a sauce pot over medium heat, add oil. -  - Once oil is heated up, add in ginger and the mushrooms mixture.
1. Saute until aromatic and until the mushrooms are slightly caramelized. -  - Add in Chinese mushrooms, bamboo and fungus. -  - Saute until well combine and aromatic.
1. Add in the boiling water. -  - *Adding boiling water will shorten the cooking time, hence containing the fragrance and flavors even more.* -  - Stir to combine well. -  - Add in dark, light soy, chili bean sauce, sugar and salt.
1. Stir to combine well. -  - Bring it up to a simmer. -  - Turn the heat down to low. -  - Add in slurry and stir to combine well.
1. Continue simmer for about 2 to 3 mins. -  - Add in beaten egg. -  - Stir for 20 secs. -  - Turn the heat up to medium.
1. Add in tofu. -  - Stir to combine well and simmer for another 1 to 2 mins. -  - The soup should thicken. -  - Taste and adjust for seasoning with salt.
1. Give it a final stir. -  - Remove from heat and transfer into the serving bowl with the coriander mixture. -  - Stir to combine well. -  - Taste and adjust for seasonings with vinegar or pepper. -  - Serve immediately with a garnish of coriander.


<i>If you find this Chinese Hot &amp; Sour Soup recipe helpful please share it to your close friends or family, thank you and good luck.</i>
